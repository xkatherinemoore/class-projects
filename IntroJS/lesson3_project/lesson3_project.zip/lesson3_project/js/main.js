/* 
NAME: Katherine Moore
MEID: KAT2341012
DATE: 6/17/2023
*/

var avengers = [
    'Thor',
    'Wasp',
    'Captain America',
    'Iron Man',
    'Hulk',
    'Vision',
    'Hank Pym',
    'Black Panther',
    'Quicksilver',
    'Mantis',
    'Spiderman'
]; //Create avengers array

document.getElementById('avengersGo').innerHTML = avengers; //sets element with 'avengersGo' id to avengers array